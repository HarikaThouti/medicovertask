from django.shortcuts import render
from yaml import serialize

from rest_framework.response import Response
from rest_framework.decorators import api_view

from .serializers import EmployeeSerializer
from .models import Employee


  
# Create your views here.
@api_view(['GET'])
def apiOverview(request):
    api_urls = {
        'List': '/employee-list',
        'Detail View':'/employee-detail/<int:id>',
        'Create':'/employee-create/',
        'Update':'/employee-update/<int:id>',
        'Delete':'/employee-detail/<int:id>',

    }
    return Response(api_urls);




@api_view(['GET'])
def ShowAll(request):
    employees = Employee.objects.all()
    serializer = EmployeeSerializer(employees, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def ViewEmployee(request, pk):
    employee = Employee.objects.get(id=pk)
    serializer = EmployeeSerializer(employee, many=False)
    return Response(serializer.data)

@api_view(['POST'])
def CreateEmployee(request):
    serializer = EmployeeSerializer(data=request.data)

    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)    

@api_view(['POST'])
def updateEmployee(request, pk):
    employee = Employee.objects.get(id=pk)
    serializer = EmployeeSerializer(instance=employee, data=request.data)

    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)

@api_view(['GET'])
def deleteEmployee(request, pk):
    employee = Employee.objects.get(id=pk)
    employee.delete()
    
    
    
    return Response('Items delete successfully!')

    
