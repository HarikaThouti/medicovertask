from django.urls import include, path
from .import views

urlpatterns = [
    
    #path('', views.apiOverview, name='apiOverview'),
    path('employee-list/', views.ShowAll, name='employee-list'),
    path('employee-detail/<int:pk>/', views.ViewEmployee, name='employee-detail'),
    path('employee-create/', views.CreateEmployee, name='employee-create'),
    path('employee-update/<int:pk>/', views.updateEmployee, name='employee-update'),
    path('employee-delete/<int:pk>/', views.deleteEmployee, name='employee-delete'),
    
]